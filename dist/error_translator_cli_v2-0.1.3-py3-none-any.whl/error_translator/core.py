from .rules import ERROR_RULES, DEFAULT_ERROR
import re

def translate_error(traceback_text: str) -> dict:
    """
    Parses traceback text and returns a human-readable explanation and fix.
    """
# Update this line inside your translate_error function:
    location_match = re.search(r'File\s+[\'"]?(.*?)[\'"]?,\s+line\s+(\d+)', traceback_text)    
    file_name = location_match.group(1) if location_match else "unknown file"
    line_number = location_match.group(2) if location_match else "unknown line"
    # Grab the last non-empty line of the traceback, which usually contains the actual error
    # print(f"\n--- DEBUG RAW INPUT ---\n{repr(traceback_text)}\n-----------------------\n")
    lines = [line.strip() for line in traceback_text.strip().split('\n') if line.strip()]
    if not lines:
        return {"explanation": "No error text provided.", "fix": "Provide a valid Python error."}
    
    actual_error_line = lines[-1]

    for rule in ERROR_RULES:
        match = rule["pattern"].search(actual_error_line)
        if match:
            # Extract the captured regex groups (e.g., the variable name)
            extracted_values = match.groups()
            
            # Format the explanation and fix using the extracted values
            explanation = rule["explanation"].format(*extracted_values)
            fix = rule["fix"].format(*extracted_values)
            
            return {
                "explanation": explanation,
                "fix": fix,
                "matched_error": actual_error_line,
                "file": file_name,
                "line": line_number,
            }

    # If no rules match, return the default payload
    return {
        "explanation": DEFAULT_ERROR["explanation"],
        "fix": DEFAULT_ERROR["fix"],
        "matched_error": actual_error_line,
        "file": file_name,
        "line": line_number,
    }